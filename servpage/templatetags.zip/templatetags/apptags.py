from django import template
from canzoni.models import *
from django.db.models import Count

register = template.Library()


@register.filter    
def subtract(value, arg):
    return value - arg


@register.assignment_tag
def slotpergruppo(group, collection):
	return canzone.objects.filter(gruppo=group).filter(slotcanzoni=collection).count()
